# Configure database (SQLite3 for development, can be changed for production)
say "Configuring database...", :green

# Database configuration is already set by Rails generator for SQLite3
# Add any custom database configuration here if needed

say "✓ Database configuration complete (using SQLite3)", :green
